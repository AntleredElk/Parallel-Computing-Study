Please just compile and run each source file. No extra work is required. 
