Please simply run any of the algorithms individually by importing the appropriate .java file.

To test mutual exclusion, locate the runnable task towards the bottom of the source code, and omit *lock.lock() from either source files. 


